module.exports = {
    mysql_config : {
        host: 'localhost',
        user: 'root',
        password: '',
        database: 'citylink',
        port: 3306
    }
};